============================================================
QoiShellExtensions.dll
Windows (64bit) Explorer Shell Extensions for QOI files      
Preview Handler and Thumbnail Provider
============================================================

Author    :  Angus Johnson                                                   
Version   :  1.0                                                            
Date      :  18 January 2022                                                 
Website   :  http://www.angusj.com                                           
Copyright :  Angus Johnson 2022                                              
License   : http://www.boost.org/LICENSE_1_0.txt                            
