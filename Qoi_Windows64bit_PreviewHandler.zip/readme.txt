============================================================
QoiPreviewHandler.dll
A 64bit Windows Explorer Preview Handler for QOI image files      
============================================================

Author    :  Angus Johnson                                                   
Version   :  0.99                                                            
Date      :  17 January 2022                                                 
Website   :  http://www.angusj.com                                           
Copyright :  Angus Johnson 2022                                              
License   : http://www.boost.org/LICENSE_1_0.txt                            
